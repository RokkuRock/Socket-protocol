#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "logdigest.h"
#include "test.h"

#ifndef LD_COUNT
# define LD_COUNT(ARR)   (sizeof (ARR) / sizeof *(ARR))
#endif

#ifndef LD_ASSERT
# include <assert.h>
# define LD_ASSERT(EXPR)      assert(EXPR)
#endif


static struct global {
	char buf[BUFSIZ];
	ld_syslog_t syslog;
	ld_multilog_t multilog;
} g;

#ifdef LD_PLATFORM_UNIX
# define LD_TEST_WATCHER
#endif

#ifdef LD_TEST_WATCHER

// Utility to get command output.
// This function null-terminates.
// This function blocks until command EOF.
static int pipe(const char *cmd, char *buf, size_t buf_size)
{
	FILE *p = popen(cmd, "r");
	if (p == NULL)
		return -1;

	size_t bytes_read = fread(buf, 1, buf_size - 1, p);
	buf[bytes_read] = '\0';

	if (pclose(p) < 0)
		return -1;

	return bytes_read;
}

static void syslog_echo(ld_syslog_t *log)
{
	printf("syslog_echo\n");
}

static void multilog_echo(ld_multilog_t *log)
{
	printf("multilog_echo\n");
}

static void test_syslog_watcher()
{
	printf("test syslog watcher\n");
	pipe("cp ../test/sys01.log ./sys01.tmp", g.buf, sizeof(g.buf));

	ld_init();

	ld_set_syslog_callback(syslog_echo);
	ld_watch_syslog("./sys01.tmp");

	// first poll should extract all syslogs on disk
	ld_poll();

	pipe("echo \"FOOO\" >> ./sys01.tmp", g.buf, sizeof(g.buf));

	// second poll picks up new entries
	ld_poll();

	ld_shutdown();
}

static void test_multilog_watcher()
{
	printf("test multilog watcher\n");

	ld_init();

	//ld_set_multilog_watcher(multilog_echo);
	//ld_watch_multilog();

	ld_shutdown();
}

#endif // LD_TEST_WATCHER

static int endswith(const char *str, const char *end)
{
	if (strlen(str) < strlen(end))
		return 0;

	return strncmp(str + strlen(str) - strlen(end), end, strlen(end)) == 0;
}

static void test_syslog_parser(syslog_test_case_t *cases, int num_cases)
{
	printf("test syslog parser\n");

	for (int i = 0; i < num_cases; i++) {
		ld_syslog_t* result = ld_parse_syslog(cases[i].src);
		ld_syslog_t* expect = &cases[i].expect;

		printf("- syslog case %03d [%s]\n", i, cases[i].desc ? cases[i].desc : cases[i].src);

		LD_ASSERT(result);
		CHECK_INT(result->type, LD_TYPE_SYSLOG);
		CHECK_INT(result->pri, expect->pri);
		CHECK_INT(result->version, expect->version);
		CHECK_STR(result->timestamp, expect->timestamp);
		CHECK_STR(result->hostname, expect->hostname);
		CHECK_STR(result->appname, expect->appname);
		CHECK_STR(result->procid, expect->procid);
		CHECK_STR(result->msgid, expect->msgid);
		//TODO: CHECK_STR(result->msg, expect->msg);

		ld_free((ld_log_t *)result);
	}
}

static void test_multilog_parser(multilog_test_case_t* cases, int num_cases)
{
	printf("test multilog parser\n");

	for (int i = 0; i < num_cases; i++) {
		ld_multilog_t* result = ld_parse_multilog(cases[i].src);
		ld_multilog_t* expect = &cases[i].expect;

		printf("- multilog case %03d [%s]\n", i, cases[i].desc ? cases[i].desc : cases[i].src);

		if (cases[i].is_src_valid) {
			LD_ASSERT(result);
			CHECK_INT(result->type, LD_TYPE_MULTILOG);
			CHECK_STR(result->timestamp, expect->timestamp);
			CHECK_STR(result->msg, expect->msg);
			ld_free((ld_log_t *)result);
		} else {
			LD_ASSERT(!result);
		}
	}
}

static void test_winevt_xml_parser(winevt_xml_test_case_t* cases, int num_cases)
{
	printf("test winevt xml parser\n");

	for (int i = 0; i < num_cases; i++) {
		ld_winevt_xml_t* result = ld_parse_winevt_xml(cases[i].src);
		ld_winevt_xml_t* expect = &cases[i].expect;

		printf("- winevt xml case %03d [%s]\n", i, cases[i].desc ? cases[i].desc : cases[i].src);

		LD_ASSERT(result);
		CHECK_INT(result->type, LD_TYPE_WINEVT_XML);
		CHECK_INT(result->eventid, expect->eventid);
		CHECK_INT(result->version, expect->version);
		CHECK_INT(result->level, expect->level);
		CHECK_INT(result->task, expect->task);
		CHECK_INT(result->opcode, expect->opcode);
		CHECK_INT(result->recordid, expect->recordid);

		ld_free((ld_log_t *)result);
	}
}


int main(int argc, char** argv)
{
#ifdef LD_TEST_INTERNAL
	test_internal();
#endif

	test_syslog_parser(syslog_tests, LD_COUNT(syslog_tests));
	test_multilog_parser(multilog_tests, LD_COUNT(multilog_tests));
	test_winevt_xml_parser(winevt_xml_tests, LD_COUNT(winevt_xml_tests));

#ifdef LD_TEST_WATCHER
	pipe("pwd", g.buf, sizeof(g.buf));
	if (!endswith(g.buf, "build\n")) {
		puts("to test unix file watchers, run the test binary from build/");
		return 0;
	}

	test_syslog_watcher();
	test_multilog_watcher();
#endif

	return 0;
}
