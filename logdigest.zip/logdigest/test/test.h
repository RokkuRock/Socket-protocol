#ifndef LD_TEST_H
#define LD_TEST_H

#ifdef LD_TEST_INTERNAL
extern void test_internal();
#endif

#define CHECK_INT(R, E)   if ((R) != (E))  printf(#R " expected %d, result is %d\n", (E), (R));
#define CHECK_STR(R, E)   if ((R) && !(E)) printf(#R " expected NULL, result is [%s]\n", (R)); \
                          else if (!(R) && (E)) printf(#R " expected [%s], result is NULL\n", (E)); \
						  else if ((R) && (E) && (strcmp((R), (E)) != 0)) printf(#R " expected [%s], result is [%s]\n", (E), (R));
#define CHECK(EXPR)       if ((EXPR) == 0) printf(#EXPR " should not result in zero/NULL\n");
#define CHECK_NULL(EXPR)  if ((EXPR) != NULL) printf(#EXPR " expected NULL");


#include "logdigest.h"

typedef struct syslog_test_case {
	const char* desc;
	const char* src;
	ld_syslog_t expect;
} syslog_test_case_t;


static syslog_test_case_t syslog_tests[] = {
	{
		"RFC 5424 Section 6.5 Example 1",
		"<34>1 2003-10-11T22:14:15.003Z mymachine.example.com su - ID47 - \xFE\xFF'su root' failed for lonvick on / dev / pts / 8",
		{
			.pri = 34,
			.version = 1,
			.timestamp = "2003-10-11T22:14:15.003Z",
			.hostname = "mymachine.example.com",
			.appname = "su",
			.procid = NULL,
			.msgid = "ID47",
			.msg = "'su root' failed for lonvick on / dev / pts / 8"
		}
	},
	{
		"RFC 5424 Section 6.5 Example 2",
		"<165>1 2003-08-24T05:14:15.000003-07:00 192.0.2.1 myproc 8710 - - %% It's time to make the do-nuts.",
		{
			.pri = 165,
			.version = 1,
			.timestamp = "2003-08-24T05:14:15.000003-07:00",
			.hostname = "192.0.2.1",
			.appname = "myproc",
			.procid = "8710",
			.msgid = NULL,
			.msg = "%% It's time to make the do-nuts."
		}
	},
	{
		"RFC 5424 Section 6.5 Example 3",
		"<165>1 2003-10-11T22:14:15.003Z mymachine.example.com evntslog - ID47 [exampleSDID@32473 iut = \"3\" eventSource =  \"Application\" eventID = \"1011\"] \xFE\xFF An application event log entry...",
		{
			.pri = 165,
			.version = 1,
			.timestamp = "2003-10-11T22:14:15.003Z",
			.hostname = "mymachine.example.com",
			.appname = "evntslog",
			.procid = NULL,
			.msgid = "ID47",
			.msg = "An application event log entry..."
		}
	},
};

typedef struct multilog_test_case {
	const char* desc;
	const char* src;
	ld_multilog_t expect;
	int is_src_valid;
} multilog_test_case_t;

static multilog_test_case_t multilog_tests[] = {
	{
		"multilog timestamp example",
		"@400000003b4a39c23294b13c fatal: out of memory",
		{
			.timestamp = "@400000003b4a39c23294b13c",
			.msg = "fatal: out of memory",
		},
		1
	},
	{
		"multilog message whitespace",
		"@400000003b4a39c2cafebabe   fatal: message\twith\ttabs",
		{
			.timestamp = "@400000003b4a39c2cafebabe",
			.msg = "fatal: message\twith\ttabs",
		},
		1
	},
	{
		"multilog empty message",
		"@400000003b4a39c2cafebabe",
		{ .type = LD_TYPE_MULTILOG },
		0
	},
	{
		"multilog wrong header",
		"@400000003b4a39c2caf!!abe",
		{.type = LD_TYPE_MULTILOG },
		0
	},
};

typedef struct winevt_xml_test_case {
	const char* desc;
	const char* src;
	ld_winevt_xml_t expect;
} winevt_xml_test_case_t;

static winevt_xml_test_case_t winevt_xml_tests[] = {
	{
		"Application Channel Sample",
		"<Event xmlns='http://schemas.microsoft.com/win/2004/08/events/event'>"
		  "<System>"
			"<Provider Name='Microsoft-Windows-Security-SPP' Guid='{E23B33B0-C8C9-472C-A5F9-F2BDFEA0F156}' EventSourceName='Software Protection Platform Service'/>"
		    "<EventID Qualifiers='16384'>16384</EventID>"
			"<Version>0</Version>"
			"<Level>4</Level>"
			"<Task>0</Task>"
			"<Opcode>0</Opcode>"
			"<Keywords>0x80000000000000</Keywords>"
			"<TimeCreated SystemTime='2023-07-19T03:01:05.9524657Z'/>"
		    "<EventRecordID>6162</EventRecordID>"
			"<Correlation/>"
			"<Execution ProcessID='0' ThreadID='0'/>"
		    "<Channel>Application</Channel>"
			"<Computer>P23157-NB-CSTI.iii.org.tw</Computer>"
			"<Security/>"
		  "</System>"
		  "<EventData>"
			"<Data>2123 - 06 - 25T03:01 : 05Z</Data>"
			"<Data>RulesEngine</Data>"
		  "</EventData>"
		"</Event>",
		{
			.eventid = 16384,
			.version = 0,
			.level = 4,
			.task = 0,
			.opcode = 0,
		    .recordid = 6162,
		}
	},
	{
		"Application Channel Sample",
		"<Event xmlns=\"http://schemas.microsoft.com/win/2004/08/events/event\">"
		  "<System>"
		  	"<Provider Name=\"Microsoft-Windows-Security-SPP\" Guid=\"{E23B33B0-C8C9-472C-A5F9-F2BDFEA0F156}\" EventSourceName=\"Software Protection Platform Service\"/>"
			"<EventID Qualifiers=\"16384\">16384</EventID>"
			"<Version>0 </Version>"
			"<Level>4 </Level>"
			"<Task>0 </Task>"
			"<Opcode>0 </Opcode>"
			"<Keywords>0x80000000000000</Keywords>"
			"<TimeCreated SystemTime=\"2023-07-20T06:32:24.3394608Z\" />"
			"<EventRecordID>6311 </EventRecordID>"
			"<Correlation/>"
			"<Execution ProcessID=\"0\" ThreadID=\"0\" />"
			"<Channel>Application</Channel>"
			"<Computer>P23157 - NB - CSTI.iii.org.tw</Computer>"
			"<Security />"
		  "</System>"
		"</Event>",
		{
			.eventid = 16384,
			.version = 0,
			.level = 4,
			.task = 0,
			.opcode = 0,
			.recordid = 6311,
		}
	},
};

#endif // LD_TEST_H
